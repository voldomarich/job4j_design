package ru.job4j.tdd;

public class AccountCinema implements Account {

}
