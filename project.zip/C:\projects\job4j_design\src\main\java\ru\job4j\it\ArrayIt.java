package ru.job4j.it;

public interface ArrayIt {
}
