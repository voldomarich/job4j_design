package ru.job4j.tdd;

public class Session3D implements Session {

}
