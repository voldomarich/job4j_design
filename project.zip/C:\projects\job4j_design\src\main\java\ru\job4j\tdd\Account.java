package ru.job4j.tdd;

public interface Account {

}
