package ru.job4j.tdd;

public interface Session {

}
