package ru.job4j.tdd;

public class Ticket3D implements Ticket {

}
